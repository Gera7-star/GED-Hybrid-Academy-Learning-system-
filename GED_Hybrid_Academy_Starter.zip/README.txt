GED Hybrid Academy — starter web app

FILES
- index.html: the app. Open it in a browser to try the prototype.

FEATURES
- Separate Teacher + Student and Mom Student dashboard views
- Seven courses
- Four starter lessons: Author's Purpose, Order of Operations, Genetics & Heredity, Economic Basics
- Create lessons and assignments
- Mark lessons and assignments complete
- Record grades and attendance
- Add calendar reminders
- Saves to this browser using local storage

IMPORTANT LIMITATIONS
- This is a prototype, not a secure login system. The role picker does not protect private information.
- Data stays in the browser/device and does not sync between devices.
- Do not store sensitive personal information or real confidential student records here.
- Publishing this static file makes the site public unless you use a hosting service with appropriate access controls.
- For secure separate accounts and syncing, a database/authentication service would need to be added.

PUBLISHING
A free static host such as GitHub Pages can publish a basic website. Follow the official instructions:
https://docs.github.com/en/pages/quickstart
A published GitHub Pages site is public on the internet. Do not upload private grades, personal details, or passwords.
